class Integer:
    def __init__(self, value):
        self.value = value
    @classmethod
    def from_float(cls, value):
        if isinstance(value, float):
            value //= 1
            return value
        return "value is not a float"
    @classmethod
    def from_roman(cls, value):
        num_roman = {"I": 1, "V": 5, "X": 10, "L": 50, "C": 100, "D": 500, "M": 1000}
        i = 0
        roman_int = 0
        while i < len(value):
            if i + 1 < len(value) and num_roman[value[i]] < num_roman[value[i + 1]]:
                roman_int += num_roman[value[i +1]] - num_roman[value[i]]
                i += 2

            else:
                roman_int += num_roman[value[i]]
                i += 1 
        return cls(roman_int)
    @classmethod
    def from_string(cls, value):
        try:
           num = value(int)
           return cls(num)
        except:
           return "wrong type"
    def add(self, integer):
        if isinstance(integer, Integer):
            return self.value + integer.value
        return "number should be an Integer instance"    
    
    
first_num = Integer(10)
second_num = Integer.from_roman("IV")
print(Integer.from_float("2.6"))
print(Integer.from_string(2.6))
print(first_num.add(second_num))    
        
        
        
        
        
        
        
           
               
        
        